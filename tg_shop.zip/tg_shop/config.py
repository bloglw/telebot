
# 机器人TOKEN
TOKEN = '1320464114:AAEG3z0LGoMmNcrVjOhByE3oIr73W7FDqUg'


# 机器人用户名，不需要加@ ！
BOT_USERNAME = 'Taobaowangbot'

# 交易费率 0.5% ---> 0.005
RATE = 0.005

# 交易完成订单过期时间，单位：天
TRADE_DELETE_TIME = 7


# 管理员列表
# 填入你的TG ID 使用机器人@getmyid_bot 获取TG ID，如有多个管理员，请使用英文逗号隔开
# 例如 [375512355, 637162135, 982379124]
ADMIN_ID = [637168038]


# 钱包配置区域
# 手续费 单位：BTC * 100000000 (0.0005 BTC --> 50000)
FEE = 50000

# 最小提现金额，单位：BTC * 100000000 (0.003 BTC --> 300000)
SMALLEST_AMOUNT = 300000


# V2_API 为你之前邮箱接受到的API，请妥善保存！
V2_API = 'da30f143-d979-4a34-855e-890a9165b001'

# 钱包密钥，blockchain 获取，具体看使用文档
# 目前使用的是BitTest2的密钥，如果收款地址不够，请创建新的钱包，填入xPub后，重启机器人
xPub = 'xpub6CdAweS1LwJaABhznuAhmYQHT8cJ6EvfLeCtDstjd8SqbsgGLTSps1Whusn4MbVfNbmu6miUuHu2YKHmG4s4q9JeEgnVDsS8YDuy5NkqRUU'

# 域名地址，我已经配置完毕，不需要修改
HOST = 'wallet.telegrampdd.com'
